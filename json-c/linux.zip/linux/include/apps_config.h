
/* Define to 1 if you have the <sys/resource.h> header file. */
#define HAVE_SYS_RESOURCE_H

/* Define if you have the `getrusage' function. */
#define HAVE_GETRUSAGE

/* #undef HAVE_JSON_TOKENER_GET_PARSE_END */
